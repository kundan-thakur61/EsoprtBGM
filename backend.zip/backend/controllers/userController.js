const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const Profile = require('../models/Profile');
const Team = require('../models/Team');
const Tournament = require('../models/Tournament');
const Wallet = require('../models/Wallet');
const Notification = require('../models/Notification');
const Transaction = require('../models/Transaction');
const logger = require('../utils/logger/logger');

// @desc    Get user profile
// @route   GET /api/v1/users/me
// @access  Private
const getUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id)
    .select('-password -refreshTokens')
    .populate('profile');

  res.json({
    success: true,
    data: { user }
  });
});

// @desc    Update user profile
// @route   PUT /api/v1/users/me
// @access  Private
const updateProfile = asyncHandler(async (req, res) => {
  const { username, email, phone, bio } = req.body;
  
  const user = await User.findById(req.user._id);
  
  if (username) user.username = username;
  if (email) user.email = email;
  if (phone) user.phone = phone;
  
  await user.save();
  
  // Update profile if bio is provided
  if (bio) {
    await Profile.findOneAndUpdate(
      { user: req.user._id },
      { bio },
      { upsert: true, new: true }
    );
  }
  
  res.json({
    success: true,
    message: 'Profile updated successfully',
    data: { user: await User.findById(req.user._id).select('-password -refreshTokens').populate('profile') }
  });
});

// @desc    Get user stats
// @route   GET /api/v1/users/:id/stats
// @access  Public
const getUserStats = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id).select('-password -refreshTokens');
  
  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found'
    });
  }
  
  res.json({
    success: true,
    data: { user }
  });
});

// @desc    Get user teams
// @route   GET /api/v1/users/me/teams
// @access  Private
const getUserTeams = asyncHandler(async (req, res) => {
  const teams = await Team.find({
    $or: [
      { captain: req.user._id },
      { 'players.user': req.user._id }
    ]
  })
  .populate('captain', 'username email')
  .populate('players.user', 'username email')
  .sort({ createdAt: -1 });

  res.json({
    success: true,
    data: { teams }
  });
});

// @desc    Get user tournaments
// @route   GET /api/v1/users/me/tournaments
// @access  Private
const getUserTournaments = asyncHandler(async (req, res) => {
  const tournaments = await Tournament.find({ participants: req.user._id })
    .populate('createdBy', 'username')
    .sort({ startDate: -1 });

  res.json({
    success: true,
    data: { tournaments }
  });
});

// @desc    Get upcoming tournaments
// @route   GET /api/v1/users/me/tournaments/upcoming
// @access  Private
const getUpcomingTournaments = asyncHandler(async (req, res) => {
  const tournaments = await Tournament.find({ 
    participants: req.user._id,
    startDate: { $gt: new Date() }
  })
  .populate('createdBy', 'username')
  .sort({ startDate: 1 });

  res.json({
    success: true,
    data: { tournaments }
  });
});

// @desc    Get completed tournaments
// @route   GET /api/v1/users/me/tournaments/completed
// @access  Private
const getCompletedTournaments = asyncHandler(async (req, res) => {
  const tournaments = await Tournament.find({ 
    participants: req.user._id,
    status: 'completed'
  })
  .populate('createdBy', 'username')
  .sort({ endDate: -1 });

  res.json({
    success: true,
    data: { tournaments }
  });
});

// @desc    Get user wallet balance
// @route   GET /api/v1/users/me/wallet
// @access  Private
const getWalletBalance = asyncHandler(async (req, res) => {
  const wallet = await Wallet.findOne({ user: req.user._id });

  res.json({
    success: true,
    data: { 
      balance: wallet ? wallet.balance : 0,
      currency: wallet ? wallet.currency : 'INR'
    }
  });
});

// @desc    Get transaction history
// @route   GET /api/v1/users/me/transactions
// @access  Private
const getTransactionHistory = asyncHandler(async (req, res) => {
  const transactions = await Transaction.find({ user: req.user._id })
    .sort({ createdAt: -1 });

  res.json({
    success: true,
    data: { transactions }
  });
});

// @desc    Get user settings
// @route   GET /api/v1/users/me/settings
// @access  Private
const getUserSettings = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { settings: {} }
  });
});

// @desc    Update user settings
// @route   PUT /api/v1/users/me/settings
// @access  Private
const updateUserSettings = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Settings updated successfully'
  });
});

// @desc    Get user friends
// @route   GET /api/v1/users/:id/friends
// @access  Public
const getUserFriends = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { friends: [] }
  });
});

// @desc    Get user followers
// @route   GET /api/v1/users/:id/followers
// @access  Public
const getUserFollowers = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { followers: [] }
  });
});

// @desc    Get user following
// @route   GET /api/v1/users/:id/following
// @access  Public
const getUserFollowing = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { following: [] }
  });
});

// @desc    Send friend request
// @route   POST /api/v1/users/friends/request
// @access  Private
const sendFriendRequest = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Friend request sent'
  });
});

// @desc    Accept friend request
// @route   POST /api/v1/users/friends/accept
// @access  Private
const acceptFriendRequest = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Friend request accepted'
  });
});

// @desc    Search users
// @route   GET /api/v1/users/search
// @access  Private
const searchUsers = asyncHandler(async (req, res) => {
  const { q } = req.query;
  
  if (!q) {
    return res.status(400).json({
      success: false,
      message: 'Search query is required'
    });
  }
  
  const users = await User.find({
    $or: [
      { username: { $regex: q, $options: 'i' } },
      { email: { $regex: q, $options: 'i' } }
    ]
  })
  .select('-password -refreshTokens')
  .limit(10);

  res.json({
    success: true,
    data: { users }
  });
});

// @desc    Get user notifications
// @route   GET /api/v1/users/me/notifications
// @access  Private
const getNotifications = asyncHandler(async (req, res) => {
  const notifications = await Notification.find({ user: req.user._id })
    .sort({ createdAt: -1 });

  res.json({
    success: true,
    data: { notifications }
  });
});

// @desc    Mark notification as read
// @route   PUT /api/v1/users/me/notifications/:id/read
// @access  Private
const markNotificationAsRead = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Notification marked as read'
  });
});

// @desc    Get user achievements
// @route   GET /api/v1/users/:id/achievements
// @access  Public
const getUserAchievements = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { achievements: [] }
  });
});

// @desc    Report user
// @route   POST /api/v1/users/report
// @access  Private
const reportUser = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Report submitted'
  });
});

// @desc    Request verification
// @route   POST /api/v1/users/verify/request
// @access  Private
const requestVerification = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Verification requested'
  });
});

// @desc    Get user devices
// @route   GET /api/v1/users/me/devices
// @access  Private
const getUserDevices = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { devices: [] }
  });
});

// @desc    Remove device
// @route   DELETE /api/v1/users/me/devices/:deviceId
// @access  Private
const removeDevice = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Device removed'
  });
});

// @desc    Get user preferences
// @route   GET /api/v1/users/me/preferences
// @access  Private
const getUserPreferences = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { preferences: {} }
  });
});

// @desc    Update user preferences
// @route   PUT /api/v1/users/me/preferences
// @access  Private
const updateUserPreferences = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Preferences updated successfully'
  });
});

// @desc    Get user activity
// @route   GET /api/v1/users/me/activity
// @access  Private
const getUserActivity = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    data: { activity: [] }
  });
});

// @desc    Update user presence
// @route   POST /api/v1/users/me/presence
// @access  Private
const updatePresence = asyncHandler(async (req, res) => {
  res.json({
    success: true,
    message: 'Presence updated'
  });
});

// @desc    Get leaderboard
// @route   GET /api/v1/users/leaderboard
// @access  Public
const getLeaderboard = asyncHandler(async (req, res) => {
  const users = await User.find({ isActive: true })
    .select('-password -refreshTokens')
    .sort({ createdAt: -1 })
    .limit(100);

  res.json({
    success: true,
    data: { users }
  });
});

module.exports = {
  getUserProfile,
  updateProfile,
  getUserStats,
  getUserTeams,
  getUserTournaments,
  getUpcomingTournaments,
  getCompletedTournaments,
  getWalletBalance,
  getTransactionHistory,
  getUserSettings,
  updateUserSettings,
  getUserFriends,
  getUserFollowers,
  getUserFollowing,
  sendFriendRequest,
  acceptFriendRequest,
  searchUsers,
  getNotifications,
  markNotificationAsRead,
  getUserAchievements,
  reportUser,
  requestVerification,
  getUserDevices,
  removeDevice,
  getUserPreferences,
  updateUserPreferences,
  getUserActivity,
  updatePresence,
  getLeaderboard
};
